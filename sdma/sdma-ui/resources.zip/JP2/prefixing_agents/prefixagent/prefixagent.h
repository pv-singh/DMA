#include <jvmti.h>

#ifndef _PREFIXAGENT_H
#define	_PREFIXAGENT_H

#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT jint JNICALL Agent_OnLoad(JavaVM *jvm, char *options, void *reserved);

#ifdef __cplusplus
}
#endif


#endif	/* _PREFIXAGENT_H */