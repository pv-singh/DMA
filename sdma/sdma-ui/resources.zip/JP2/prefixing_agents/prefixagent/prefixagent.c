/*
(C) Copyright Walter Binder, Philippe Moret, Alex Villazón 2008.
Permission to copy, use, and modify (only the included source file,
 modification of the binaries is not permitted) the  software is
granted provided this copyright notice appears in all copies. 
This software is provided "as is" without express or implied warranty, and with no claim as to its suitability for any purpose.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "prefixagent.h"
#include <jvmti.h>

// initialization of the agent
JNIEXPORT jint JNICALL Agent_OnLoad(JavaVM *jvm, char *options, void *reserved)
{
    jvmtiEnv* jvmti_env;
    jvmtiCapabilities cap;
    const char* prefix ="ch_dag_usi_jp2_";
    
    printf("starting simple agent\n");	
    if ((*jvm)->GetEnv(jvm,(void **) &jvmti_env, JVMTI_VERSION_1_0)!=0)
    {
        printf("Error while getting jvmti_env\n");
    }

    memset(&cap, 0, sizeof(cap));
    cap.can_set_native_method_prefix = 1;
    if ((*jvmti_env)->AddCapabilities(jvmti_env, &cap) != JVMTI_ERROR_NONE) fprintf(stderr, "Cannot add capabilities.");

    (*jvmti_env)->SetNativeMethodPrefix(jvmti_env,prefix);
    printf("native prefix is set to %s\n", prefix);	

    return 0;
}
